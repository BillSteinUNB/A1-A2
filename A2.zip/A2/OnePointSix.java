/**
 * @author Alain Shogonyha Nasombwa
 * He did not do the question,
 * Did not answer in teams. 
 * 
 */

public class OnePointSix {
    
}
