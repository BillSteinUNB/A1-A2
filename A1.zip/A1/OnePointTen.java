import java.util.Arrays; 

import java.util.Random; 

 

public class OnePointTen { 

 

    public static double[] prefixAverage1(double[] x) { 

    

        long startTime = System.currentTimeMillis(); 

        int n = x.length; 

        double[] a = new double[n]; 

    

        for (int j=0; j < n; j++) { 

            double total = 0; 

            for (int i=0; i <= j; i++) 

                total += x[i]; 

            a[j] = total / (j+1); 

        } 

    

        long endTime = System.currentTimeMillis(); 

        long executionTime = endTime - startTime; 

        System.out.println("Execution time: " + executionTime + " ms"); 

        return a; 

    

    } 

 

    public static double[] prefixAverage2(double[] x) { 

    

        long startTime = System.currentTimeMillis(); 

        int n = x.length; 

        double[] a = new double[n]; 

        double total = 0; 

    

        for (int j=0; j < n; j++) { 

            total += x[j]; 

            a[j] = total / (j+1); 

        } 

    

        long endTime = System.currentTimeMillis(); 

        long executionTime = endTime - startTime; 

        System.out.println("Execution time: " + executionTime + " ms"); 

        return a; 

    } 

 

    public static void main(String[] args) { 

        

        int inputSize = 10000; 

        Random rand = new Random(); 

        double[] doubleArrayIn = new double[inputSize]; 

        double[] doubleArray = new double[inputSize]; 

        

        for (int i = 0; i < inputSize; i++) { 

            doubleArrayIn[i] = rand.nextDouble() * inputSize; 

        } 

        

        doubleArray = prefixAverage1(doubleArrayIn); 

        doubleArray = prefixAverage2(doubleArrayIn); 

    } 

} 