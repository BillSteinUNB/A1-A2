/**
  * @author Bill Stein #3714982
  Alain Shogonya Nasombwa did not complete the question and therefore Bill Stein completed it
  */

  import java.util.*;

  public class OnePointEighteen {
      
      // Hash code using polynomial rolling hash function with parameter a
      private static int polynomialHash(String s, int a) {
          int hash = 0;
          for (int i = 0; i < s.length(); i++) {
              hash = (hash * a + s.charAt(i)) % 1000000007;
          }
          return hash;
      }
      
      // Hash code using simple hash function that sums up ASCII values of characters
      private static int simpleHash(String s) {
          int hash = 0;
          for (int i = 0; i < s.length(); i++) {
              hash += s.charAt(i);
          }
          return hash;
      }
      
      public static void main(String[] args) {
        String[] phoneNumbers = {"123-456-7890", "234-567-8901", "345-678-9012",
                "456-789-0123", "567-890-1234", "678-901-2345", "789-012-3456"};
    
        int[] aValues = {31, 37, 41, 43, 47};
    
        for (int a : aValues) {
            HashMap<Integer, ArrayList<String>> polynomialHashTable = new HashMap<>();
            HashMap<Integer, ArrayList<String>> simpleHashTable = new HashMap<>();
    
            int polynomialCollisions = 0;
            int simpleCollisions = 0;
    
            for (String phoneNumber : phoneNumbers) {
                int polynomialHashCode = polynomialHash(phoneNumber, a);
                ArrayList<String> polynomialBucket = polynomialHashTable.getOrDefault(polynomialHashCode, new ArrayList<>());
                polynomialBucket.add(phoneNumber);
                polynomialHashTable.put(polynomialHashCode, polynomialBucket);
    
                int simpleHashCode = simpleHash(phoneNumber);
                ArrayList<String> simpleBucket = simpleHashTable.getOrDefault(simpleHashCode, new ArrayList<>());
                simpleBucket.add(phoneNumber);
                simpleHashTable.put(simpleHashCode, simpleBucket);
            }
    
            for (int hashCode : polynomialHashTable.keySet()) {
                ArrayList<String> bucket = polynomialHashTable.get(hashCode);
                if (bucket.size() > 1) {
                    polynomialCollisions += bucket.size() - 1;
                }
            }
    
            for (int hashCode : simpleHashTable.keySet()) {
                ArrayList<String> bucket = simpleHashTable.get(hashCode);
                if (bucket.size() > 1) {
                    simpleCollisions += bucket.size() - 1;
                }
            }
    
            System.out.println("a = " + a);
            System.out.println("Polynomial hash code: " + (double)polynomialCollisions / phoneNumbers.length);
            System.out.println("Simple hash code: " + (double)simpleCollisions / phoneNumbers.length);
        }
    }
      }

      /**
       * 
The above code implements the polynomial rolling hash function with parameter `a` and the simple hash function that sums up ASCII values of characters. 
It then initializes hash tables for each hash code method and counts collisions for each phone number. Finally, it prints the collision rates for each hash code method.

Note that the collision rates may vary depending on the input data and the hash code parameters.

       */
  