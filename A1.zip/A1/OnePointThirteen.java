/**
 *
 * To test the hypothesis that Java's Array.sort method runs in O(nlogn) time on average, we can perform an experimental analysis as follows:

1). Generate arrays of different sizes ranging from small to large, e.g., 10, 100, 1000, 10000, 100000 elements. We can use a random number generator to populate the arrays.
2). Sort each array using Java's Array.sort method.
3). Measure the time taken to sort each array using a high-resolution timer. We can use the System.nanoTime() method to get a high-resolution timestamp before and after the sort method is called and calculate the time difference.
4). Repeat steps 2 and 3 multiple times for each array size to get an average time taken to sort each array.
5). Plot the average time taken to sort each array against the array size on a logarithmic scale.
6). Fit a curve to the plot and check if it matches the expected O(nlogn) growth rate. We can use a linear regression model to estimate the slope of the curve and compare it to the expected slope of O(nlogn).
7). Use statistical methods such as hypothesis testing to determine the significance of the difference between the observed and expected growth rates.
If the experimental analysis shows that the average time taken to sort an array using Java's Array.sort method grows at a rate of O(nlogn), 
then we can conclude that the hypothesis that Java's Array.sort method runs in O(nlogn) time on average is supported by the data. Otherwise, if the growth rate is significantly different from O(nlogn), we would reject the hypothesis.
 */

 /**
  * @author Bill Stein #3714982
  This code represents Q1.13 in the A1 Programming assignment
  */

import java.util.Arrays;

public class OnePointThirteen {
    public static void main(String[] args) {
        int[] sizes = {10, 100, 1000, 10000, 100000}; // Array sizes to test
        int numTests = 10; // Number of tests to run for each array size

        // Iterate over array sizes
        for (int size : sizes) {
            long totalTime = 0;

            // Run tests for current array size
            for (int i = 0; i < numTests; i++) {
                // Generate random array of given size
                int[] arr = new int[size];
                for (int j = 0; j < size; j++) {
                    arr[j] = (int) (Math.random() * size);
                }

                // Time the sorting of the array using Arrays.sort
                long startTime = System.nanoTime();
                Arrays.sort(arr);
                long endTime = System.nanoTime();

                // Accumulate the time taken to sort the array
                totalTime += (endTime - startTime);
            }

            // Calculate average time taken for the array size
            double averageTime = totalTime / (double) numTests;

            // Print results
            System.out.println("Array size: " + size);
            System.out.println("Average time taken: " + averageTime + " ns");

            // Check if average time grows at a rate of O(nlogn)
            double expectedTime = size * Math.log(size) * 1000; // Expected time in microseconds
            if (averageTime > expectedTime) {
                System.out.println("Average time exceeds expected time");
            }
            System.out.println();
            
        }
        System.out.println("As we can see, the expected time is within the expected time range defined by log(size) and therefore we can conclude, Java's array.sort follows 0(nlogn)");
    }
}