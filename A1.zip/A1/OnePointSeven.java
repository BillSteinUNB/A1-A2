/**
 * @author Sam Mossman
 */

public class OnePointSeven { 

    public static int[][] multiplyMatrices(int[][] array1, int[][] array2) { 
  
      int size = array1.length; 
  
      int[][] newArray = new int[size][size]; 
  
   
  
      for (int i = 0; i < size; i++) { 
  
        for (int j = 0; j < size; j++) { 
  
          for (int k = 0; k < size; k++) { 
  
            newArray[i][j] += array1[i][k] * array2[k][j]; 
  
          } 
  
        } 
  
      } 
  
      return newArray; 
  
    } 
  
  } 