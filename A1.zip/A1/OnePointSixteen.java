/**
  * @author Alain Shogonya Nasombwa
  Did not include Screenshot or Printing tests.
  */

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class OnePointSixteen {

    private ArrayList<ArrayList<String>> edgeList;

    public OnePointSixteen() {
        edgeList = new ArrayList<>();
    }

    public void addingEdges(String start, String end) {
        ArrayList<String> edge = new ArrayList<>();
        ArrayList<String> backEdge = new ArrayList<>();
        edge.add(end);
        edge.add(start);
        backEdge.add(end);
        backEdge.add(start);
        edgeList.add(edge);
        edgeList.add(backEdge);
    }

    public Set<String> getLinks(String ver) {
        Set<String> link = new HashSet<>();
        for (int i = 0; i < edgeList.size(); i++) {
            if (edgeList.get(i).get(0).equals(ver)) {
                link.add(edgeList.get(i).get(1));
            }
        }
        return link;
    }

    public Set<String> getAllVertices() {
        Set<String> vertices = new HashSet<>();
        for (int i = 0; i < edgeList.size(); i++) {
            vertices.add(edgeList.get(i).get(0));
            vertices.add(edgeList.get(i).get(1));
        }
        return vertices;
    }

    private void difsRec(String ver, Set<String> visited) {
        visited.add(ver);
        System.out.print(ver + " ");
        Set<String> link = getLinks(ver);
        for (String connection : link) {
            if (!visited.contains(connection)) {
                difsRec(connection, visited);
            }
        }
    }

    public void difs(String start) {
        Set<String> visited = new HashSet<>();
        difsRec(start, visited);
    }
}
