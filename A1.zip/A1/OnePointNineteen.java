import java.util.Random; 

public class OnePointNineteen { 

  public static void mergeSort(int[] a, int n) { 

    if (n < 2) { 

        return; 

    } 

    int mid = n / 2; 

    int[] l = new int[mid]; 

    int[] r = new int[n - mid]; 

 

    for (int i = 0; i < mid; i++) { 

        l[i] = a[i]; 

    } 

    for (int i = mid; i < n; i++) { 

        r[i - mid] = a[i]; 

    } 

    mergeSort(l, mid); 

    mergeSort(r, n - mid); 

 

    merge(a, l, r, mid, n - mid); 

  } 

 

  public static void merge( 

    int[] a, int[] l, int[] r, int left, int right) { 

 

      int i = 0, j = 0, k = 0; 

      while (i < left && j < right) { 

          if (l[i] <= r[j]) { 

              a[k++] = l[i++]; 

          } 

          else { 

              a[k++] = r[j++]; 

          } 

      } 

      while (i < left) { 

          a[k++] = l[i++]; 

      } 

      while (j < right) { 

          a[k++] = r[j++]; 

      } 

  } 

 

  public static void quickSort(int arr[], int begin, int end) { 

      if (begin < end) { 

          int partitionIndex = partition(arr, begin, end); 

 

          quickSort(arr, begin, partitionIndex-1); 

          quickSort(arr, partitionIndex+1, end); 

      } 

  } 

 

  private static int partition(int arr[], int begin, int end) { 

    int pivot = arr[end]; 

    int i = (begin-1); 

 

    for (int j = begin; j < end; j++) { 

        if (arr[j] <= pivot) { 

            i++; 

 

            int swapTemp = arr[i]; 

            arr[i] = arr[j]; 

            arr[j] = swapTemp; 

        } 

    } 

 

    int swapTemp = arr[i+1]; 

    arr[i+1] = arr[end]; 

    arr[end] = swapTemp; 

 

    return i+1; 

  } 

 

  public static void main(String[] args) { 

    Random random = new Random(); 

    int size = 10000; 

 

    int[] randomArray = new int[size]; 

    int[] quarterSorted = new int[size]; 

    int[] halfSorted = new int[size]; 

    int[] threeQuarterSorted = new int[size]; 

 

    //fills array with random integers 

    for (int i = 0; i < size; i++) { 

      randomArray[i] = random.nextInt(10000); 

    } 

 

    //fills quarter sorted array 

    for (int i = 0; i < size/4; i++) { 

      quarterSorted[i] = i; 

    } 

    for (int i = size/4; i < size; i++) { 

      quarterSorted[i] = random.nextInt(10000); 

    } 

 

    //fills half sorted array 

    for (int i = 0; i < size/2; i++) { 

      halfSorted[i] = i; 

    } 

    for (int i = size/2; i < size; i++) { 

      halfSorted[i] = random.nextInt(10000); 

    } 

 

    //fills three quarter sorted array 

    for (int i = 0; i < (size/4)*3; i++) { 

      threeQuarterSorted[i] = i; 

    } 

    for (int i = (size/4)*3; i < size; i++) { 

      threeQuarterSorted[i] = random.nextInt(10000); 

    } 

 

    int[] randomCopy = randomArray; 

    long start = System.currentTimeMillis(); 

    mergeSort(randomArray, size); 

    long end = System.currentTimeMillis(); 

    long time = end - start; 

    System.out.println("\nMerge Sort random array"); 

    System.out.println("Execution Time: " + time + "ms"); 

    start = System.currentTimeMillis(); 

    quickSort(randomCopy, 0, size-1); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("Quick Sort random array"); 

    System.out.println("Execution Time: " + time + "ms"); 

 

    int[] quarterCopy = quarterSorted; 

    start = System.currentTimeMillis(); 

    mergeSort(quarterSorted, size); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("\nMerge Sort array that is a quarter sorted"); 

    System.out.println("Execution Time: " + time + "ms"); 

    start = System.currentTimeMillis(); 

    quickSort(quarterCopy, 0, size-1); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("Quick Sort array that is a quarter sorted"); 

    System.out.println("Execution Time: " + time + "ms"); 

 

    int[] halfCopy = halfSorted; 

    start = System.currentTimeMillis(); 

    mergeSort(halfSorted, size); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("\nMerge Sort array that is half sorted"); 

    System.out.println("Execution Time: " + time + "ms"); 

    start = System.currentTimeMillis(); 

    quickSort(halfCopy, 0, size-1); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("Quick Sort array that is half sorted"); 

    System.out.println("Execution Time: " + time + "ms"); 

 

    int[] threeQuarterCopy = threeQuarterSorted; 

    start = System.currentTimeMillis(); 

    mergeSort(threeQuarterSorted, size); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("\nMerge Sort array that is three quarters sorted"); 

    System.out.println("Execution Time: " + time + "ms"); 

    start = System.currentTimeMillis(); 

    quickSort(threeQuarterCopy, 0, size-1); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("Quick Sort array that is three quarters sorted"); 

    System.out.println("Execution Time: " + time + "ms"); 

 

  } 

} 