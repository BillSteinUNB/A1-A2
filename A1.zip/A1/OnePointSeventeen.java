/**
 * @author Bill Stein #3714982
 * This code represents Q1.17 of the A1 programming Assignment
 * 
 * To perform a comparative analysis of collision rates for various hash codes for character strings in Java, we can follow the below steps:

1 - Implement a hash table that uses separate chaining to handle collisions.
2 - Generate a set of character strings, either randomly or by reading from text files found on the internet.
3 - Implement multiple hash functions for character strings, such as polynomial hash codes for different values of the parameter a.
4 - For each hash function, insert the character strings into the hash table and count the number of collisions where different strings map to the same hash code.
5 - Compare the collision rates for each hash function and analyze their performance.
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


    public class OnePointSeventeen {
        private static final int TABLE_SIZE = 10000;
    
        public static void main(String[] args) {
            List<String> strings = readStringsFromFile("Q5Test.txt");
            HashTable[] tables = new HashTable[5];
            tables[0] = new HashTable(new PolynomialHash(31));
            tables[1] = new HashTable(new PolynomialHash(41));
            tables[2] = new HashTable(new PolynomialHash(53));
            tables[3] = new HashTable(new PolynomialHash(5));
            tables[4] = new HashTable(new PolynomialHash(2));
    
            for (HashTable table : tables) {
                for (String str : strings) {
                    table.insert(str);
                }
            }
    
            System.out.printf("%-10s%-10s%-10s%-10s%-10s%-10s\n", "Hash", "a", "Collisions", "Load Factor", "Table Size", "String Count");
            for (HashTable table : tables) {
                int collisions = table.countCollisions();
                double loadFactor = (double) table.size() / table.tableSize();
                System.out.printf("%-10s%-10d%-10d%-10.2f%-10d%-10d\n", table.hashFunction().name(), table.hashFunction().parameter(), collisions, loadFactor, table.tableSize(), table.size());
            }
        }
    
        private static List<String> readStringsFromFile(String filePath) {
            List<String> strings = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] words = line.split(" ");
                    for (String word : words) {
                        word = word.toLowerCase().replaceAll("[^a-z0-9]", "");
                        strings.add(word);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return strings;
        }
    
        static class HashTable {
            private final HashFunction hashFunction;
            private final LinkedList<String>[] table;
    
            private int size;
    
            public HashTable(HashFunction hashFunction) {
                this.hashFunction = hashFunction;
                this.table = new LinkedList[TABLE_SIZE];
                for (int i = 0; i < TABLE_SIZE; i++) {
                    table[i] = new LinkedList<>();
                }
                this.size = 0;
            }
    
            public HashFunction hashFunction() {
                return hashFunction;
            }
    
            public int tableSize() {
                return table.length;
            }
    
            public int size() {
                return size;
            }
    
            public void insert(String str) {
                int index = hashFunction.hash(str) % TABLE_SIZE;
                LinkedList<String> list = table[index];
                if (!list.contains(str)) {
                    list.add(str);
                    size++;
                }
            }
    
        public int countCollisions() {
                int collisions = 0;
                for (LinkedList<String> list : table) {
                    if (list.size() > 1) {
                        collisions += list.size() - 1;
                    }
                }
                return collisions;
            }
        }
        
        interface HashFunction {
            int hash(String str);
            String name();
            int parameter();
        }
        
        static class PolynomialHash implements HashFunction {
            private final int a;
            private final int m = 31;
        
            public PolynomialHash(int a) {
                this.a = a;
            }
        
            @Override
            public int hash(String str) {
                int hash = 0;
                for (int i = 0; i < str.length(); i++) {
                    int charCode = str.charAt(i);
                    hash = (hash * a + charCode) % m;
                }
                return hash;
            }
        
            @Override
            public String name() {
                return "Polynomial";
            }
        
            @Override
            public int parameter() {
                return a;
            }
        }
    }
    
    /**
     * 
In this implementation, we first read a sample text file and store each word in a list of strings. We then create five hash tables using 
different polynomial hash codes for different values of the parameter a. We insert all the strings into each hash table and count the number of collisions where different strings map to the same hash code. Finally, we print out the collision rates, load factors, and other relevant information for each hash function.

To test this implementation, we can use different text files found on the internet and compare the collision 
rates for each hash function. We can also try different values of the parameter a for the polynomial hash codes and see how it affects the collision rates.

     */
