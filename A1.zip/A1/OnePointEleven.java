import java.util.Arrays; 

import java.util.Random; 

 

public class OnePointEleven { 

 

/** Returns the sum of the integers in given array. */ 

public static int example1(int[] arr) { 

    int n = arr.length, total = 0; 

    for (int j=0; j < n; j++) 

        total += arr[j]; 

    return total; 

} 

 

/** Returns the sum of the integers with even index in given array. */ 

public static int example2(int[] arr) { 

    int n = arr.length, total = 0; 

    for (int j=0; j < n; j += 2) 

        total += arr[j]; 

    return total; 

} 

 

/** Returns the sum of the prefix sums of given array. */ 

public static int example3(int[] arr) { 

    int n = arr.length, total = 0; 

    for (int j=0; j < n; j++) 

        for (int k=0; k <= j; k++) 

            total += arr[j]; 

    return total; 

} 

 

/** Returns the sum of the prefix sums of given array. */ 

public static int example4(int[] arr) { 

    int n = arr.length, prefix = 0, total = 0; 

    for (int j=0; j < n; j++) { 

        prefix += arr[j]; 

        total += prefix; 

    } 

    return total; 

} 

 

/** Returns the number of times second array stores sum of prefix sums from first. */ 

public static int example5(int[] first, int[] second) { 

    int n = first.length, count = 0; 

    for (int i=0; i < n; i++) { 

        int total = 0; 

        for (int j=0; j < n; j++) 

        for (int k=0; k <= j; k++) 

        total += first[k]; 

        if (second[i] == total) count++; 

    } 

    return count; 

} 

 

 public static void main(String[] args) { 

      

     int arrayLength = 1000; 

     int output; 

     int[] intArrayIn = new int[arrayLength]; 

     int[] intArrayIn2 = new int[arrayLength]; 

     Random rand = new Random(); 

      

     for (int i = 0; i < arrayLength; i++) { 

        intArrayIn[i] = rand.nextInt(arrayLength); 

        intArrayIn2[i] = rand.nextInt(arrayLength); 

     } 

      

     //example1 

     long startTime = System.currentTimeMillis(); 

     output = example1(intArrayIn); 

     long endTime = System.currentTimeMillis(); 

     long executionTime = endTime - startTime; 

     System.out.println("Execution time: " + executionTime + " ms"); 

      

     //example2 

     startTime = System.currentTimeMillis(); 

     output = example2(intArrayIn); 

     endTime = System.currentTimeMillis(); 

     executionTime = endTime - startTime; 

     System.out.println("Execution time: " + executionTime + " ms"); 

      

     //example3 

     startTime = System.currentTimeMillis(); 

     output = example3(intArrayIn); 

     endTime = System.currentTimeMillis(); 

     executionTime = endTime - startTime; 

     System.out.println("Execution time: " + executionTime + " ms"); 

      

     //example4 

     startTime = System.currentTimeMillis(); 

     output = example4(intArrayIn); 

     endTime = System.currentTimeMillis(); 

     executionTime = endTime - startTime; 

     System.out.println("Execution time: " + executionTime + " ms"); 

      

     //example5 

     startTime = System.currentTimeMillis(); 

     output = example5(intArrayIn, intArrayIn2); 

     endTime = System.currentTimeMillis(); 

     executionTime = endTime - startTime; 

     System.out.println("Execution time: " + executionTime + " ms"); 

 

} 

} 