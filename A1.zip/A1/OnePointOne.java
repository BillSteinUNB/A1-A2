import java.util.Scanner; 

 

public class OnePointOne { 

    public static void main(String[] args) { 

        

        Scanner input = new Scanner(System.in); 

        System.out.print("Enter an integer: "); 

        int num = input.nextInt(); 

        

        long startTime = System.currentTimeMillis(); 

        

        if (num % 2 == 0) { 

            System.out.println(num + " is even."); 

        } else { 

            System.out.println(num + " is odd."); 

        } 

        

        long endTime = System.currentTimeMillis(); 

        long executionTime = endTime - startTime; 

        System.out.println("Execution time: " + executionTime + " ms"); 

    } 

} 

// The size of the integer has no real impact on execution time. *Check PNG*