import java.util.*;
/**
 * @author Bill Stein #3714982
 * This code represents question 1.6 of Assignment 1 - Programming
 */
public class OnePointSix {
    public static void main(String[] args) {
        System.out.println("\n------------------\n");
        int[] arrInt = { 11, 2, 92, 134, 5, 16, 1 };
        System.out.println("Original Int array: " + Arrays.toString(arrInt));
        arrIntegerQuickSort(arrInt, 0, arrInt.length - 1);
        System.out.println("Sorted Int array: " + Arrays.toString(arrInt));
        System.out.println("\n------------------\n");
        
        double[] arrDouble = { 3.22, 1.5, 3.73, 52.1, 4.93, 0.512 };
        System.out.println("Original Double array: " + Arrays.toString(arrDouble));
        arrDoubleQuickSort(arrDouble, 0, arrDouble.length - 1);
        System.out.println("Sorted Double array: " + Arrays.toString(arrDouble));
        System.out.println("\n------------------\n");
        

        String[] arrString = {"computer", "lounge", "elevator", "monkey", "idontknow"};
        System.out.println("Original String array: " + Arrays.toString(arrString));
        arrStringQuickSort(arrString, 0, arrString.length - 1);
        System.out.println("Sorted String array: " + Arrays.toString(arrString));
        System.out.println("\n------------------\n");

        char[] arrChar = {'s', 'c', 'a', 'e', 'z'};
        System.out.println("Original array: " + Arrays.toString(arrChar));
        arrCharQuickSort(arrChar, 0, arrChar.length - 1);
        System.out.println("Sorted array: " + Arrays.toString(arrChar));
        System.out.println("\n------------------\n");

        System.out.println("Testing n Length double arrays");
        
        System.out.println("n = 50:");
        double[] n50 = new double[50];

        for(int i = 0; i<50; i++){
            n50[i] = Math.random();
        }
        System.out.println("Starting Sort:");
        long start1 = System.nanoTime();
        arrDoubleQuickSort(n50,0,n50.length-1);
        long end1 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end1-start1));
        System.out.println("\n------------------\n");

        System.out.println("n = 200:");
        double[] n200 = new double[200];

        for(int i = 0; i<200; i++){
            n200[i] = Math.random();
        }
        System.out.println("Starting Sort:");
        long start2 = System.nanoTime();
        arrDoubleQuickSort(n200,0,n200.length-1);
        long end2 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end2-start2));
        System.out.println("\n------------------\n");

        System.out.println("n = 500:");
        double[] n500 = new double[500];

        for(int i = 0; i<500; i++){
            n500[i] = Math.random();
        }
        System.out.println("Starting Sort:");
        long start3 = System.nanoTime();
        arrDoubleQuickSort(n500,0,n500.length-1);
        long end3 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end3-start3));
        System.out.println("\n------------------\n");

        System.out.println("n = 5000:");
        double[] n5000 = new double[5000];

        for(int i = 0; i<5000; i++){
            n5000[i] = Math.random();
        }
        System.out.println("Starting Sort:");
        long start4 = System.nanoTime();
        arrDoubleQuickSort(n5000,0,n5000.length-1);
        long end4 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end4-start4));
        System.out.println("\n------------------\n");

        System.out.println("n = 50000:");
        double[] n50000 = new double[50000];

        for(int i = 0; i<50000; i++){
            n50000[i] = Math.random();
        }

        System.out.println("Starting Sort:");
        long start5= System.nanoTime();
        arrDoubleQuickSort(n50000,0,n50000.length-1);
        long end5 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end5-start5));
        System.out.println("\n------------------\n");
        System.out.println("n = 5000000:");
        double[] n5000000 = new double[5000000];

        for(int i = 0; i<5000000; i++){
            n5000000[i] = Math.random();
        }
        System.out.println("Starting Sort:");
        long start6 = System.nanoTime();
        arrDoubleQuickSort(n5000000,0,n5000000.length-1);
        long end6 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end6-start6));
        System.out.println("\n------------------\n");

        System.out.println("Question: Analyze how Array Length affects Execution time");

        System.out.println("\n------------------\n");

        System.out.println("Similar to Merge sort, two main things were observed, 1 being as Array length went up so did execution time: " + 
        " Quick sort on average took half the time of Merge sort, but also followed the same concept of the bigger n values being more consistent in their nanosecond values");
        System.out.println("\n------------------\n");

    }
    
    public static void arrIntegerQuickSort(int[] arr, int left, int right) {
        if (left < right) {
            int partitionIndex = arrIntegerPartition(arr, left, right);
            arrIntegerQuickSort(arr, left, partitionIndex - 1);
            arrIntegerQuickSort(arr, partitionIndex + 1, right);
        }
    }
    
    private static int arrIntegerPartition(int[] arr, int left, int right) {
        int pivot = arr[right];
        int i = left - 1;
        for (int j = left; j < right; j++) {
            if (arr[j] < pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[right];
        arr[right] = temp;
        return i + 1;
    }

    public static void arrDoubleQuickSort(double[] arr, int left, int right) {
        if (left < right) {
            int partitionIndex = arrDoublePartition(arr, left, right);
            arrDoubleQuickSort(arr, left, partitionIndex - 1);
            arrDoubleQuickSort(arr, partitionIndex + 1, right);
        }
    }
    
    private static int arrDoublePartition(double[] arr, int left, int right) {
        double pivot = arr[right];
        int i = left - 1;
        for (int j = left; j < right; j++) {
            if (arr[j] < pivot) {
                i++;
                double temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        double temp = arr[i + 1];
        arr[i + 1] = arr[right];
        arr[right] = temp;
        return i + 1;
    }

    public static void arrStringQuickSort(String[] arr, int left, int right) {
        if (left < right) {
            int partitionIndex = arrStringPartition(arr, left, right);
            arrStringQuickSort(arr, left, partitionIndex - 1);
            arrStringQuickSort(arr, partitionIndex + 1, right);
        }
    }
    
    private static int arrStringPartition(String[] arr, int left, int right) {
        String pivot = arr[right];
        int i = left - 1;
        for (int j = left; j < right; j++) {
            if (arr[j].compareTo(pivot) < 0) {
                i++;
                String temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        String temp = arr[i + 1];
        arr[i + 1] = arr[right];
        arr[right] = temp;
        return i + 1;
    }
    
    public static void arrCharQuickSort(char[] arr, int left, int right) {
        if (left < right) {
            int partitionIndex = arrCharPartition(arr, left, right);
            arrCharQuickSort(arr, left, partitionIndex - 1);
            arrCharQuickSort(arr, partitionIndex + 1, right);
        }
    }
    
    private static int arrCharPartition(char[] arr, int left, int right) {
        char pivot = arr[right];
        int i = left - 1;
        for (int j = left; j < right; j++) {
            if (arr[j] < pivot) {
                i++;
                char temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        char temp = arr[i + 1];
        arr[i + 1] = arr[right];
        arr[right] = temp;
        return i + 1;
    }
    
    
    
}
