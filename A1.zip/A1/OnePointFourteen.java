/**
 * @author Sam Mossman
 */

import java.util.*; 

public class OnePointFourteen { 

 

  private Queue<Order> buyQueue; 

  private Queue<Order> sellQueue; 

 

  public OnePointFourteen() { 

      buyQueue = new LinkedList<>(); 

      sellQueue = new LinkedList<>(); 

  } 

 

  public void processOrder(Order order) { 

      if (order.getType() == "Buy") { 

          buyOrder(order); 

      } 

      else if (order.getType() == "Sell") { 

            sellOrder(order); 

      } 

  } 

 

  private void buyOrder(Order buyOrder) { 

      boolean orderProcessed = false; 

      if (!sellQueue.isEmpty()) { 

          Order sellOrder = sellQueue.peek(); 

          if (sellOrder.getCost() <= buyOrder.getCost()) { 

              sellQueue.remove(); 

              System.out.println("Buy Order: " + buyOrder + "\nSell Order: 			" + sellOrder); 

              orderProcessed = true; 

          } 

      } 

      if (!orderProcessed) { 

          buyQueue.add(buyOrder); 

          System.out.println(buyOrder + " is queued"); 

      } 

  } 

 

  private void sellOrder(Order sellOrder) { 

      boolean orderProcessed = false; 

      if(!buyQueue.isEmpty()) { 

          Order buyOrder = buyQueue.peek(); 

          if (sellOrder.getCost() <= buyOrder.getCost()) { 

              buyQueue.remove(); 

              System.out.println("Sell Order: " + sellOrder + "\nBuy 				Order: " + buyOrder); 

              orderProcessed = true; 

          } 

      } 

      if (!orderProcessed) { 

          sellQueue.add(sellOrder); 

          System.out.println(sellOrder + " is queued"); 

      } 

  } 

 

  public static void main(String[] args) { 

      OnePointFourteen system = new OnePointFourteen(); 

 

      Order buy1 = new Order("Buy", 35, 5.0); 

      Order sell1 = new Order("Sell", 35, 5.0); 

      system.processOrder(buy1); 

      system.processOrder(sell1); 

 

      Order sell2 = new Order("Sell", 147, 96.0); 

      system.processOrder(sell2); 

 

      Order buy2 = new Order("Buy", 147, 46.0); 

      system.processOrder(buy2); 

  } 

} 

 

class Order { 

    private String type; 

    private int amount; 

    private double cost; 

 

    public Order(String typeIn, int amountIn, double costIn) { 

        type = typeIn; 

        amount = amountIn; 

        cost = costIn; 

    } 

 

    public String getType() { 

        return type; 

    } 

 

    public int getAmount() { 

        return amount; 

    } 

 

    public double getCost() { 

        return cost; 

    } 

 

    public String toString() { 

        return type + " " + amount + " shares for $" + cost + " a share"; 

    } 

} 