import java.util.Arrays; 

import java.util.Random; 

 

public class OnePointFour { 

    public static void main(String[] args) { 

        

        int arrayLength = 5000000; 

        int[] intArr = new int[arrayLength]; 

        double[] doubleArr = new double[arrayLength]; 

        char[] charArr = new char[arrayLength]; 

        String[] stringArr = new String[arrayLength]; 

        Random rand = new Random(); 

        

        for (int i = 0; i < arrayLength; i++) { 

            intArr[i] = rand.nextInt(arrayLength); 

            doubleArr[i] = rand.nextDouble() * arrayLength; 

            charArr[i] = (char) (rand.nextInt(26) + 'a'); 

            stringArr[i] = generateRandomString(rand.nextInt(10) + 1); 

        } 

        

        long startTime, endTime, executionTime; 

        

        // Sorting integers 

        startTime = System.currentTimeMillis(); 

        insertionSort(intArr); 

        endTime = System.currentTimeMillis(); 

        executionTime = endTime - startTime; 

        System.out.println("Sorted integers: " + Arrays.toString(intArr)); 

        System.out.println("Execution time (integers): " + executionTime + " ms"); 

        

        // Sorting doubles 

        startTime = System.currentTimeMillis(); 

        insertionSort(doubleArr); 

        endTime = System.currentTimeMillis(); 

        executionTime = endTime - startTime; 

        System.out.println("Sorted doubles: " + Arrays.toString(doubleArr)); 

        System.out.println("Execution time (doubles): " + executionTime + " ms"); 

        

        // Sorting characters 

        startTime = System.currentTimeMillis(); 

        insertionSort(charArr); 

        endTime = System.currentTimeMillis(); 

        executionTime = endTime - startTime; 

        System.out.println("Sorted characters: " + Arrays.toString(charArr)); 

        System.out.println("Execution time (characters): " + executionTime + " ms"); 

        

        // Sorting strings 

        startTime = System.currentTimeMillis(); 

        insertionSort(stringArr); 

        endTime = System.currentTimeMillis(); 

        executionTime = endTime - startTime; 

        System.out.println("Sorted strings: " + Arrays.toString(stringArr)); 

        System.out.println("Execution time (strings): " + executionTime + " ms"); 

    } 

    

    public static void insertionSort(int[] arr) { 

        for (int i = 1; i < arr.length; i++) { 

            int key = arr[i]; 

            int j = i - 1; 

            while (j >= 0 && arr[j] > key) { 

                arr[j+1] = arr[j]; 

                j--; 

            } 

            arr[j+1] = key; 

        } 

    } 

    

    public static void insertionSort(double[] arr) { 

        for (int i = 1; i < arr.length; i++) { 

            double key = arr[i]; 

            int j = i - 1; 

            while (j >= 0 && arr[j] > key) { 

                arr[j+1] = arr[j]; 

                j--; 

            } 

            arr[j+1] = key; 

        } 

    } 

    

    public static void insertionSort(char[] arr) { 

        for (int i = 1; i < arr.length; i++) { 

            char key = arr[i]; 

            int j = i - 1; 

            while (j >= 0 && arr[j] > key) { 

                arr[j+1] = arr[j]; 

                j--; 

            } 

            arr[j+1] = key; 

        } 

    } 

    

    public static void insertionSort(String[] arr) { 

        for (int i = 1; i < arr.length-1; i++) { 

            String key = arr[i]; 

            int j = i -1; 

            while (j >= 0 && arr[j].compareTo(key) > 0) { 

                arr[j+1] = arr[j]; 

                j--; 

            } 

            arr[j+1] = key; 

        } 

    } 

    

    public static String generateRandomString(int length) { 

        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; 

        Random rand = new Random(); 

        StringBuilder sb = new StringBuilder(length); 

        for (int i = 0; i < length; i++) { 

        sb.append(characters.charAt(rand.nextInt(characters.length()))); 

        } 

        return sb.toString(); 

    }   

} 

/**
 * Execution Times: 

n=50 

execution time (integers) = , execution time (doubles)=,  

execution time (char)=, execution time (strings)= 

n=200 

execution time (integers) = 0ms, execution time (doubles)=0ms,  

execution time (char)=0ms, execution time (strings)=0ms 

n=500 A

execution time (integers) =2ms, execution time (doubles)=2ms,  

execution time (char)=2ms, execution time (strings)=4ms 

n=50000 

execution time (integers) =1030ms, execution time (doubles)=1754,  

execution time (char)=986, execution time (strings)=5994ms 

n=500000 

execution time (integers) =106721ms, execution time (doubles)=187448ms,  

execution time (char)=112765ms, execution time (strings)=1706748ms 
 */