/**
 * @author Sam Mossman
 */

import java.util.Random; 

public class OnePointThree { 

  public static void main(String[] args) { 

    Random random = new Random(); 

    int size = 50000; 

 

    //Integers 

    int[] intArray = new int[size]; 

    for (int i = 0; i < size; i++) { 

      intArray[i] = random.nextInt(10000); 

    } 

    long start = System.currentTimeMillis(); 

    bubbleSort(intArray); 

    long end = System.currentTimeMillis(); 

    long time = end - start; 

    System.out.println("\nBubble Sort on array of Integers of size " + size); 

    System.out.println("Execution Time: " + time + "ms"); 

 

    //Doubles 

    Double[] doubleArray = new Double[size]; 

    for (int i = 0; i < size; i++) { 

      doubleArray[i] = random.nextDouble() * 10000; 

    } 

    start = System.currentTimeMillis(); 

    bubbleSort(doubleArray); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("\nBubble Sort on array of Doubles of size " + size); 

    System.out.println("Execution Time: " + time + "ms"); 

 

 

    //Characters 

    char[] charArray = new char[size]; 

    for (int i = 0; i < size; i++) { 

      charArray[i] = (char) (random.nextInt(26) + 'a'); 

    } 

    start = System.currentTimeMillis(); 

    bubbleSort(charArray); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("\nBubble Sort on array of Characters of size " + size); 

    System.out.println("Execution Time: " + time + "ms"); 

 

    //Strings 

    int stringLength = 10; 

    String[] stringArray = new String[size]; 

    for (int i = 0; i < size; i++) { 

    StringBuilder sb = new StringBuilder(); 

      for (int j = 0; j < stringLength; j++) { 

        sb.append((char) (random.nextInt(26) + 'a')); 

      } 

    stringArray[i] = sb.toString(); 

    } 

    start = System.currentTimeMillis(); 

    bubbleSort(stringArray); 

    end = System.currentTimeMillis(); 

    time = end - start; 

    System.out.println("\nBubble Sort on array of Strings of size " + size); 

    System.out.println("Execution Time: " + time + "ms"); 

  } 

  //Sorts Integers 

  public static void bubbleSort(int[] array) { 

    for (int i = 0; i < array.length - 1; i++) { 

        for (int j = 0; j < array.length - i - 1; j++) { 

            if (array[j] > array[j + 1]) { 

                int temp = array[j]; 

                array[j] = array[j + 1]; 

                array[j + 1] = temp; 

            } 

        } 

    } 

  } 

  //Sorts Doubles 

  public static void bubbleSort(Double[] array) { 

    for (int i = 0; i < array.length - 1; i++) { 

        for (int j = 0; j < array.length - i - 1; j++) { 

            if (array[j] > array[j + 1]) { 

                Double temp = array[j]; 

                array[j] = array[j + 1]; 

                array[j + 1] = temp; 

            } 

        } 

    } 

  } 

  //Sorts Characters 

  public static void bubbleSort(char[] array) { 

    for (int i = 0; i < array.length - 1; i++) { 

        for (int j = 0; j < array.length - i - 1; j++) { 

            if (array[j] > array[j + 1]) { 

                char temp = array[j]; 

                array[j] = array[j + 1]; 

                array[j + 1] = temp; 

            } 

        } 

    } 

  } 

  //Sorts Strings 

  public static void bubbleSort(String[] array) { 

    for (int i = 0; i < array.length - 1; i++) { 

        for (int j = 0; j < array.length - i - 1; j++) { 

            if (array[j].compareTo(array[j + 1]) > 0) { 

                String temp = array[j]; 

                array[j] = array[j + 1]; 

                array[j + 1] = temp; 

            } 

        } 

    } 

  } 

 

} 