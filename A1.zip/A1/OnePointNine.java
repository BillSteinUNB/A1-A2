/**
 * @author Bill Stein #3714982
 * This code represents Q1.9 in the A1 programming assignment
 */

public class OnePointNine {

    public static void main(String[] args) {
        OnePointNine bst = new OnePointNine();
        
        bst.insert(25);
        bst.insert(2);
        bst.insert(9);
        bst.insert(55);
        bst.insert(32);
        bst.insert(16);
        bst.insert(1);
        bst.insert(14);
        bst.insert(33);
        bst.insert(98);
        System.out.println("\n------------------");
        System.out.println("Inorder traversal:");
        bst.inorderTraversal();
        System.out.println("\n------------------");
        System.out.println("Search for 3:");
        System.out.println(bst.search(3));
        
        System.out.println("Search for 4:");
        System.out.println(bst.search(4));

        System.out.println("Search for 16:");
        System.out.println(bst.search(16));
    }
    
    private Node root;
    
    private class Node {
        private int value;
        private Node left;
        private Node right;
        
        public Node(int value) {
            this.value = value;
            this.left = null;
            this.right = null;
        }
    }
    
    public OnePointNine() {
        root = null;
    }
    
    public void insert(int value) {
        root = insert(root, value);
    }
    
    private Node insert(Node node, int value) {
        if (node == null) {
            return new Node(value);
        }
        
        if (value < node.value) {
            node.left = insert(node.left, value);
        } else if (value > node.value) {
            node.right = insert(node.right, value);
        }
        
        return node;
    }
    
    public boolean search(int value) {
        return search(root, value);
    }
    
    private boolean search(Node node, int value) {
        if (node == null) {
            return false;
        }
        
        if (node.value == value) {
            return true;
        } else if (value < node.value) {
            return search(node.left, value);
        } else {
            return search(node.right, value);
        }
    }
    
    public void inorderTraversal() {
        inorderTraversal(root);
    }
    
    private void inorderTraversal(Node node) {
        if (node != null) {
            inorderTraversal(node.left);
            System.out.print(node.value + " ");
            inorderTraversal(node.right);
        }
    }
    
    
}

