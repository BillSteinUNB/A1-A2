import java.util.*;
/**
 * @author Bill Stein #3714982
 * This code represents Q1.5 of Assignment 1 - Programming
 */
public class OnePointFive {
    
    public static void main(String[] args) {

        System.out.println("\n------------------\n");

        int[] arrInt = {5, 32, 8, 6, 2, 73, 1, 41};

        System.out.println("Before we sort Int[]: ");
        System.out.print(Arrays.toString(arrInt));
        mergeSortInt(arrInt);
        System.out.println("\nSorted int[] Array: ");
        System.out.println(Arrays.toString(arrInt));
        System.out.println("\n------------------\n");

        double[] arrDouble = {5.2, 3.9, 8.5, 11.7, 2.2, 7.3, 21.6, 4.9};

        System.out.println("Before we sort Double[]: ");
        System.out.print(Arrays.toString(arrDouble));
        mergeSortDouble(arrDouble);
        System.out.println("\nSorted Double[] Array: ");
        System.out.println(Arrays.toString(arrDouble));
        System.out.println("\n------------------\n");

        char[] arrChar = {'e', 'c', 'h', 'z', 'b', 'y', 'a', 'd'};

        System.out.println("Before we sort Char[]: ");
        System.out.print(Arrays.toString(arrChar));
        mergeSortChar(arrChar);
        System.out.println("\nSorted Char[] Array: ");
        System.out.println(Arrays.toString(arrChar));
        System.out.println("\n------------------\n");

        String[] arrString = {"apple", "plane", "cherry", "boat", "dog", "grape", "human", "math"};

        System.out.println("Before we sort String[]: ");
        System.out.print(Arrays.toString(arrString));
        mergeSortString(arrString);
        System.out.println("\nSorted String[] Array: ");
        System.out.println(Arrays.toString(arrString));
        System.out.println("\n------------------\n");

        System.out.println("Testing Execution Time: ");
        System.out.println("n = 50:");
        double[] n50 = new double[50];

        for(int i = 0; i<50; i++){
            n50[i] = Math.random();
        }
        System.out.println("Sorting now:");
        long start1 = System.nanoTime();
        mergeSortDouble(n50);
        long end1 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end1-start1));
        System.out.println("\n------------------\n");

        System.out.println("n = 200:");
        double[] n200 = new double[200];

        for(int i = 0; i<200; i++){
            n200[i] = Math.random();
        }
        System.out.println("Sorting now:");
        long start2 = System.nanoTime();
        mergeSortDouble(n200);
        long end2 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end2-start2));
        System.out.println("\n------------------\n");

        System.out.println("n = 500:");

         double[] n500 = new double[500];

        for(int i = 0; i<500; i++){
            n500[i] = Math.random();
        }
        System.out.println("Sorting now:");
        long start3 = System.nanoTime();
        mergeSortDouble(n500);
        long end3 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end3-start3));
        System.out.println("\n------------------\n");

        System.out.println("n = 5000:");

        double[] n5000 = new double[5000];

        for(int i = 0; i<5000; i++){
            n5000[i] = Math.random();
        }
        System.out.println("Sorting now:");
        long start4 = System.nanoTime();
        mergeSortDouble(n5000);
        long end4 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end4-start4));
        System.out.println("\n------------------\n");

        System.out.println("n = 50000:");

        double[] n50000 = new double[50000];

        for(int i = 0; i<50000; i++){
            n50000[i] = Math.random();
        }
        System.out.println("Sorting now:");
        long start5 = System.nanoTime();
        mergeSortDouble(n50000);
        long end5 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end5-start5));
        System.out.println("\n------------------\n");

        System.out.println("n = 5000000");

        double[] n5000000 = new double[5000000];

        for(int i = 0; i<5000000; i++){
            n5000000[i] = Math.random();
        }
        System.out.println("Sorting now:");
        long start6 = System.nanoTime();
        mergeSortDouble(n5000000);
        long end6 = System.nanoTime();
        System.out.println("Elapsed Time in nano seconds: "+ (end6-start6));
        System.out.println("\n------------------\n");

        System.out.println("Question: Analyze how Array Length affects Execution time");

        System.out.println("\n------------------\n");

        System.out.println("Answer: I noticed two things about array length and its correlation to execution time, 1: Obviously as array length increased so " + 
        "did execution time, but one it was not linear, and actually sizes 200-500 preformed pretty similarly to eachother (as it was the only array group without a massive difference between one another.)" );
        System.out.println("\n------------------\n");
        System.out.println("The second thing I noticed was in the lower numbers say between n50-n5000, the discrepency in the data was very random as the array size was not big enough, the nanosecond time could double between tests" + 
        "Where as for N5000000 it was almost always 840million range, and thats due to over 5000000 array spots, the average of the random double is going to end up making them run about the same");
        System.out.println("\n------------------\n");
    }
    
    public static void mergeSortInt(int[] arr) {
        if (arr.length > 1) {
            int mid = arr.length / 2;
            int[] leftHalf = Arrays.copyOfRange(arr, 0, mid);
            int[] rightHalf = Arrays.copyOfRange(arr, mid, arr.length);

            mergeSortInt(leftHalf);
            mergeSortInt(rightHalf);

            int i = 0, j = 0, k = 0;

            while (i < leftHalf.length && j < rightHalf.length) {
                if (leftHalf[i] < rightHalf[j]) {
                    arr[k] = leftHalf[i];
                    i++;
                } else {
                    arr[k] = rightHalf[j];
                    j++;
                }
                k++;
            }

            while (i < leftHalf.length) {
                arr[k] = leftHalf[i];
                i++;
                k++;
            }

            while (j < rightHalf.length) {
                arr[k] = rightHalf[j];
                j++;
                k++;
            }

        }
    }

    public static void mergeSortDouble(double[] arr) {
        if (arr.length > 1) {
            int mid = arr.length / 2;
            double[] leftHalf = Arrays.copyOfRange(arr, 0, mid);
            double[] rightHalf = Arrays.copyOfRange(arr, mid, arr.length);
    
            mergeSortDouble(leftHalf);
            mergeSortDouble(rightHalf);
    
            int i = 0, j = 0, k = 0;
    
            while (i < leftHalf.length && j < rightHalf.length) {
                if (leftHalf[i] < rightHalf[j]) {
                    arr[k] = leftHalf[i];
                    i++;
                } else {
                    arr[k] = rightHalf[j];
                    j++;
                }
                k++;
            }
    
            while (i < leftHalf.length) {
                arr[k] = leftHalf[i];
                i++;
                k++;
            }
    
            while (j < rightHalf.length) {
                arr[k] = rightHalf[j];
                j++;
                k++;
            }
        }
    }

    public static void mergeSortChar(char[] arr) {
        if (arr.length > 1) {
            int mid = arr.length / 2;
            char[] leftHalf = Arrays.copyOfRange(arr, 0, mid);
            char[] rightHalf = Arrays.copyOfRange(arr, mid, arr.length);
    
            mergeSortChar(leftHalf);
            mergeSortChar(rightHalf);
    
            int i = 0, j = 0, k = 0;
    
            while (i < leftHalf.length && j < rightHalf.length) {
                if (leftHalf[i] < rightHalf[j]) {
                    arr[k] = leftHalf[i];
                    i++;
                } else {
                    arr[k] = rightHalf[j];
                    j++;
                }
                k++;
            }
    
            while (i < leftHalf.length) {
                arr[k] = leftHalf[i];
                i++;
                k++;
            }
    
            while (j < rightHalf.length) {
                arr[k] = rightHalf[j];
                j++;
                k++;
            }
        }
    }

    public static void mergeSortString(String[] arr) {
        if (arr.length > 1) {
            int mid = arr.length / 2;
            String[] leftHalf = Arrays.copyOfRange(arr, 0, mid);
            String[] rightHalf = Arrays.copyOfRange(arr, mid, arr.length);
    
            mergeSortString(leftHalf);
            mergeSortString(rightHalf);
    
            int i = 0, j = 0, k = 0;
    
            while (i < leftHalf.length && j < rightHalf.length) {
                if (leftHalf[i].compareTo(rightHalf[j]) < 0) {
                    arr[k] = leftHalf[i];
                    i++;
                } else {
                    arr[k] = rightHalf[j];
                    j++;
                }
                k++;
            }
    
            while (i < leftHalf.length) {
                arr[k] = leftHalf[i];
                i++;
                k++;
            }
    
            while (j < rightHalf.length) {
                arr[k] = rightHalf[j];
                j++;
                k++;
            }
        }
    }
    
}
