 /**
  * @author Alain Shogonya Nasombwa
  Did not include Screenshot or Printing tests.
  */

public class OnePointTwo {

    public static void main(String[] args) {

        int[] a = new int[5000000];

        for (int i = 0; i < a.length; i++) {
            a[i] = (int) (Math.random() * 100000);
        }

        long startTime = System.nanoTime();
        maxVal(a);
        long endTime = System.nanoTime();
        long totalTime = endTime - startTime;

        System.out.println();
        System.out.println("Execution time: " + totalTime);
    }

    public static void maxVal(int[] a) {

        int max = a[0];
        int len = a.length;

        for (int i = 1; i < len; i++) {
            if (a[i] > max) {
                max = a[i];
            }
        }

        System.out.println(max);
    }

}
