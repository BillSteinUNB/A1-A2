import java.util.*; 

  /**
  * @author Riley Nesbitt
  */

public class OnePointFifteen { 

    public static void main(String[] args) { 

        PriorityQueue<Job> jobQueue = new PriorityQueue<Job>(new Comparator<Job>() { 

            public int compare(Job j1, Job j2) { 

                return j2.getPriority() - j1.getPriority(); 

            } 

        }); 

        

        Scanner scanner = new Scanner(System.in); 

        

        int timeSlice = 0; 

        while (true) { 

            System.out.print("Time slice " + timeSlice + ": \n"); 

            String command = scanner.nextLine(); 

            if (command.equals("no new job this slice")) { 

                System.out.println("No job added this slice."); 

            } else if (command.equals("add job")) { 

                String name = scanner.nextLine(); 

                int length = scanner.nextInt(); 

                int priority = scanner.nextInt(); 

                Job job = new Job(name, length, priority); 

                jobQueue.offer(job); 

                System.out.println("Added job " + name + " with length " + length + " and priority " + priority + "."); 

            } 

            

            // check if there is a job currently running 

            if (!jobQueue.isEmpty()) { 

                Job currentJob = jobQueue.peek(); 

                currentJob.decrementTimeLeft(); 

                System.out.println("Running job " + currentJob.getName() + "."); 

                

                // remove job from queue if it has finished 

                if (currentJob.getTimeLeft() == 0) { 

                    jobQueue.poll(); 

                    System.out.println("Finished job " + currentJob.getName() + "."); 

                } 

            } 

            

            timeSlice++; 

        } 

    } 

} 

 

class Job { 

    private String name; 

    private int length; 

    private int priority; 

    private int timeLeft; 

    

    public Job(String name, int length, int priority) { 

        this.name = name; 

        this.length = length; 

        this.priority = priority; 

        this.timeLeft = length; 

    } 

    

    public String getName() { 

        return name; 

    } 

    

    public int getPriority() { 

        return priority; 

    } 

    

    public int getTimeLeft() { 

        return timeLeft; 

    } 

    

    public void decrementTimeLeft() { 

        timeLeft--; 

    } 

} 