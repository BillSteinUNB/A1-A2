/**
  * @author Alain Shogonya Nasombwa
  Did not include Screenshot or Printing tests.
  */

public class OnePointEight {
    public static void main(String[] args) {
        int n = 1000;
        int[][] a = new int[n][n];
        int[][] b = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = (int) (Math.random() * 100);
                b[i][j] = (int) (Math.random() * 100);
            }
        }

        long startTime = System.nanoTime();
        multiplying2SqrMat(a, b);
        long endTime = System.nanoTime();

        System.out.println();

        long totalTime = endTime - startTime;
        System.out.println("no of elements" + (n * n));
        System.out.println("Execution time: " + totalTime);
    }

    public static void multiplying2SqrMat(int[][] a, int[][] b) {
        int len = a.length;
        int[][] a2 = new int[len][len];
        int sum = 0;
        int round = 0;
        int i = 0;

        while (round < len) {
            while (i < len) {
                for (int j = 0; j < len; j++) {
                    sum += a[i][j] * b[j][round];
                }
                a2[i][round] = sum;
                i++;
                sum = 0;
            }
            i = 0;
            round++;
        }
    }
}
